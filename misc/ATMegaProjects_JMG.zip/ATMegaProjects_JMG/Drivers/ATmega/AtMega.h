/*
 * AtMega644.h
 *
 *  Created on: 28.03.2013
 *      Author: Jean-Martin George
 */

#ifndef ATMEGA_H_
#define ATMEGA_H_


#include "uC.h"
#include "SPI.h"
#include "TWI.h"
#include "USART.h"
#include "ADC.h"


#endif /* ATMEGA_H_ */
